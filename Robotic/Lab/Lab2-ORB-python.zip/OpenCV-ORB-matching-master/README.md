# OpenCV-ORB-matching
This program match the real time video with a picture using OpenCV ORB.

It runs under Ubuntu 14.04 and OpenCV 3.1.0

To run this code:
$ python orbmatch.py Book.png

When there are more than 10 mathces, the match lines will change the color from black to random.
The figure shows the result.
